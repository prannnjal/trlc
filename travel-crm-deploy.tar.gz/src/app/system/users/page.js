import UserManagement from '@/components/admin/UserManagement'

export default function SystemUsersPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <UserManagement />
    </div>
  )
}
