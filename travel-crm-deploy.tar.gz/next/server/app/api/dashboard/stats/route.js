"use strict";(()=>{var e={};e.id=6041,e.ids=[6041],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},98216:e=>{e.exports=require("net")},35816:e=>{e.exports=require("process")},76162:e=>{e.exports=require("stream")},74026:e=>{e.exports=require("string_decoder")},95346:e=>{e.exports=require("timers")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},27923:(e,t,s)=>{s.r(t),s.d(t,{originalPathname:()=>C,patchFetch:()=>R,requestAsyncStorage:()=>E,routeModule:()=>O,serverHooks:()=>T,staticGenerationAsyncStorage:()=>l});var a={};s.r(a),s.d(a,{GET:()=>p});var r=s(49303),o=s(88716),u=s(60670),n=s(87070),i=s(35042);let c={query:i.IO,queryOne:i.pP,execute:i.ht,prepare:e=>({get:t=>(0,i.pP)(e,t),all:t=>(0,i.IO)(e,t),run:t=>(0,i.ht)(e,t)})};var d=s(68408);async function p(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return n.NextResponse.json({success:!1,message:"Access denied. No token provided."},{status:401});let s=t.substring(7);if(!await (0,d.WX)(s))return n.NextResponse.json({success:!1,message:"Invalid token."},{status:401});let[a,r,o,u,i]=await Promise.all([c.queryOne("SELECT COUNT(*) as count FROM customers"),c.queryOne("SELECT COUNT(*) as count FROM leads"),c.queryOne("SELECT COUNT(*) as count FROM quotes"),c.queryOne("SELECT COUNT(*) as count FROM bookings"),c.queryOne("SELECT COUNT(*) as count FROM payments")]),p=await c.query(`
      SELECT status, COUNT(*) as count 
      FROM leads 
      GROUP BY status
    `),O=await c.query(`
      SELECT priority, COUNT(*) as count 
      FROM leads 
      GROUP BY priority
    `),E=await c.query(`
      SELECT status, COUNT(*) as count 
      FROM quotes 
      GROUP BY status
    `),l=await c.query(`
      SELECT status, COUNT(*) as count 
      FROM bookings 
      GROUP BY status
    `),T=await c.query(`
      SELECT status, COUNT(*) as count 
      FROM payments 
      GROUP BY status
    `),C=await c.query(`
      SELECT 
        DATE_FORMAT(created_at, '%Y-%m') as month,
        SUM(amount) as revenue
      FROM payments 
      WHERE status = 'completed' 
        AND created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
      GROUP BY DATE_FORMAT(created_at, '%Y-%m')
      ORDER BY month
    `),R=await c.query(`
      SELECT 
        a.type,
        a.subject,
        a.description,
        a.created_at,
        c.first_name,
        c.last_name,
        l.source,
        l.destination
      FROM activities a
      LEFT JOIN customers c ON a.related_id = c.id AND a.related_type = 'customer'
      LEFT JOIN leads l ON a.related_id = l.id AND a.related_type = 'lead'
      ORDER BY a.created_at DESC
      LIMIT 10
    `),y=await c.query(`
      SELECT source, COUNT(*) as count
      FROM leads
      GROUP BY source
      ORDER BY count DESC
      LIMIT 5
    `),m=await c.query(`
      SELECT 
        'Lead to Quote' as stage,
        (SELECT COUNT(*) FROM quotes) / (SELECT COUNT(*) FROM leads) * 100 as rate
      UNION ALL
      SELECT 
        'Quote to Booking' as stage,
        (SELECT COUNT(*) FROM bookings) / (SELECT COUNT(*) FROM quotes) * 100 as rate
      UNION ALL
      SELECT 
        'Booking to Payment' as stage,
        (SELECT COUNT(*) FROM payments WHERE status = 'completed') / (SELECT COUNT(*) FROM bookings) * 100 as rate
    `),q={overview:{totalCustomers:a.count,totalLeads:r.count,totalQuotes:o.count,totalBookings:u.count,totalPayments:i.count},leads:{byStatus:p,byPriority:O},quotes:{byStatus:E},bookings:{byStatus:l},payments:{byStatus:T},revenue:{monthly:C},activities:{recent:R},performance:{topSources:y,conversionRates:m}};return n.NextResponse.json({success:!0,data:{stats:q}})}catch(e){return console.error("Get dashboard stats error:",e),n.NextResponse.json({success:!1,message:"Internal server error"},{status:500})}}let O=new r.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/dashboard/stats/route",pathname:"/api/dashboard/stats",filename:"route",bundlePath:"app/api/dashboard/stats/route"},resolvedPagePath:"D:\\codes\\andA - Copy\\src\\app\\api\\dashboard\\stats\\route.js",nextConfigOutput:"",userland:a}),{requestAsyncStorage:E,staticGenerationAsyncStorage:l,serverHooks:T}=O,C="/api/dashboard/stats/route";function R(){return(0,u.patchFetch)({serverHooks:T,staticGenerationAsyncStorage:l})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),a=t.X(0,[8948,6898,2216,7070,9853],()=>s(27923));module.exports=a})();