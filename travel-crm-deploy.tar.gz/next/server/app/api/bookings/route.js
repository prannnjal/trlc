"use strict";(()=>{var e={};e.id=1946,e.ids=[1946],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},98216:e=>{e.exports=require("net")},35816:e=>{e.exports=require("process")},76162:e=>{e.exports=require("stream")},74026:e=>{e.exports=require("string_decoder")},95346:e=>{e.exports=require("timers")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},65252:(e,t,s)=>{s.r(t),s.d(t,{originalPathname:()=>_,patchFetch:()=>O,requestAsyncStorage:()=>g,routeModule:()=>m,serverHooks:()=>q,staticGenerationAsyncStorage:()=>b});var r={};s.r(r),s.d(r,{GET:()=>l,POST:()=>p});var o=s(49303),a=s(88716),n=s(60670);s(87070);var i=s(35042),u=s(68408),c=s(78776);let d=c.object({customer_id:c.number().integer().required(),quote_id:c.number().integer().allow(null),destination:c.string().min(2).max(200).required(),departure_date:c.date().required(),return_date:c.date().allow(""),travelers_count:c.number().integer().min(1).default(1),total_amount:c.number().positive().required(),status:c.string().valid("confirmed","pending","cancelled","completed").default("pending"),notes:c.string().allow("")});async function l(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return Response.json({success:!1,message:"Access denied. No token provided."},{status:401});let s=t.substring(7);if(!await (0,u.WX)(s))return Response.json({success:!1,message:"Invalid token."},{status:401});let{searchParams:r}=new URL(e.url),o=parseInt(r.get("page"))||1,a=parseInt(r.get("limit"))||10,n=r.get("search")||"",c=r.get("status")||"",d=r.get("sortBy")||"created_at",l=r.get("sortOrder")||"DESC",p="WHERE 1=1",m=[];n&&(p+=" AND (b.destination LIKE ? OR b.booking_reference LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ?)",m.push(`%${n}%`,`%${n}%`,`%${n}%`,`%${n}%`)),c&&(p+=" AND b.status = ?",m.push(c));let g=`
      SELECT COUNT(*) as total 
      FROM bookings b
      LEFT JOIN customers c ON b.customer_id = c.id
      ${p}
    `,b=(await queryOne(g,m)).total,q=(o-1)*a,_=`
      SELECT b.*, 
             c.first_name, c.last_name, c.email, c.phone,
             q.title as quote_title, q.total_amount as quote_amount
      FROM bookings b
      LEFT JOIN customers c ON b.customer_id = c.id
      LEFT JOIN quotes q ON b.quote_id = q.id
      ${p}
      ORDER BY b.${d} ${l}
      LIMIT ? OFFSET ?
    `,O=await (0,i.IO)(_,[...m,a,q]);return Response.json({success:!0,data:{bookings:O,pagination:{page:o,limit:a,total:b,pages:Math.ceil(b/a)}}})}catch(e){return console.error("Get bookings error:",e),Response.json({success:!1,message:"Internal server error"},{status:500})}}async function p(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return Response.json({success:!1,message:"Access denied. No token provided."},{status:401});let s=t.substring(7),r=await (0,u.WX)(s);if(!r)return Response.json({success:!1,message:"Invalid token."},{status:401});let o=await e.json(),{error:a,value:n}=d.validate(o);if(a)return Response.json({success:!1,message:"Validation error",errors:a.details.map(e=>e.message)},{status:400});let c=`BK-${Date.now()}-${Math.random().toString(36).substr(2,4).toUpperCase()}`,l=await (0,i.ht)(`
      INSERT INTO bookings (
        customer_id, quote_id, destination, departure_date, return_date,
        travelers_count, total_amount, status, notes, booking_reference, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,[n.customer_id,n.quote_id||null,n.destination,n.departure_date,n.return_date||null,n.travelers_count,n.total_amount,n.status,n.notes||null,c,r.id]),p=await queryOne(`
      SELECT b.*, 
             c.first_name, c.last_name, c.email, c.phone,
             q.title as quote_title, q.total_amount as quote_amount
      FROM bookings b
      LEFT JOIN customers c ON b.customer_id = c.id
      LEFT JOIN quotes q ON b.quote_id = q.id
      WHERE b.id = ?
    `,[l.insertId]);return Response.json({success:!0,message:"Booking created successfully",data:{booking:p}},{status:201})}catch(e){return console.error("Create booking error:",e),Response.json({success:!1,message:"Internal server error"},{status:500})}}let m=new o.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/bookings/route",pathname:"/api/bookings",filename:"route",bundlePath:"app/api/bookings/route"},resolvedPagePath:"D:\\codes\\andA - Copy\\src\\app\\api\\bookings\\route.js",nextConfigOutput:"",userland:r}),{requestAsyncStorage:g,staticGenerationAsyncStorage:b,serverHooks:q}=m,_="/api/bookings/route";function O(){return(0,n.patchFetch)({serverHooks:q,staticGenerationAsyncStorage:b})}}};var t=require("../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[8948,6898,2216,91,7070,9853],()=>s(65252));module.exports=r})();