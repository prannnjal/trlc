"use strict";(()=>{var e={};e.id=7649,e.ids=[7649],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},98216:e=>{e.exports=require("net")},35816:e=>{e.exports=require("process")},76162:e=>{e.exports=require("stream")},74026:e=>{e.exports=require("string_decoder")},95346:e=>{e.exports=require("timers")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},13465:(e,t,s)=>{s.r(t),s.d(t,{originalPathname:()=>_,patchFetch:()=>h,requestAsyncStorage:()=>g,routeModule:()=>l,serverHooks:()=>y,staticGenerationAsyncStorage:()=>b});var r={};s.r(r),s.d(r,{GET:()=>d,POST:()=>m});var a=s(49303),n=s(88716),o=s(60670);s(87070);var i=s(35042),u=s(68408),p=s(78776);let c=p.object({booking_id:p.number().integer().required(),amount:p.number().positive().required(),currency:p.string().length(3).default("INR"),payment_method:p.string().valid("credit_card","bank_transfer","cash","check","other").required(),status:p.string().valid("pending","completed","failed","refunded").default("pending"),transaction_id:p.string().allow(""),payment_date:p.date().allow(""),notes:p.string().allow("")});async function d(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return Response.json({success:!1,message:"Access denied. No token provided."},{status:401});let s=t.substring(7);if(!await (0,u.WX)(s))return Response.json({success:!1,message:"Invalid token."},{status:401});let{searchParams:r}=new URL(e.url),a=parseInt(r.get("page"))||1,n=parseInt(r.get("limit"))||10,o=r.get("search")||"",p=r.get("status")||"",c=r.get("payment_method")||"",d=r.get("sortBy")||"created_at",m=r.get("sortOrder")||"DESC",l="WHERE 1=1",g=[];o&&(l+=" AND (p.transaction_id LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ? OR b.booking_reference LIKE ?)",g.push(`%${o}%`,`%${o}%`,`%${o}%`,`%${o}%`)),p&&(l+=" AND p.status = ?",g.push(p)),c&&(l+=" AND p.payment_method = ?",g.push(c));let b=`
      SELECT COUNT(*) as total 
      FROM payments p
      LEFT JOIN bookings b ON p.booking_id = b.id
      LEFT JOIN customers c ON b.customer_id = c.id
      ${l}
    `,y=(await queryOne(b,g)).total,_=(a-1)*n,h=`
      SELECT p.*, 
             b.booking_reference, b.destination,
             c.first_name, c.last_name, c.email, c.phone
      FROM payments p
      LEFT JOIN bookings b ON p.booking_id = b.id
      LEFT JOIN customers c ON b.customer_id = c.id
      ${l}
      ORDER BY p.${d} ${m}
      LIMIT ? OFFSET ?
    `,O=await (0,i.IO)(h,[...g,n,_]);return Response.json({success:!0,data:{payments:O,pagination:{page:a,limit:n,total:y,pages:Math.ceil(y/n)}}})}catch(e){return console.error("Get payments error:",e),Response.json({success:!1,message:"Internal server error"},{status:500})}}async function m(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return Response.json({success:!1,message:"Access denied. No token provided."},{status:401});let s=t.substring(7),r=await (0,u.WX)(s);if(!r)return Response.json({success:!1,message:"Invalid token."},{status:401});let a=await e.json(),{error:n,value:o}=c.validate(a);if(n)return Response.json({success:!1,message:"Validation error",errors:n.details.map(e=>e.message)},{status:400});let p=await (0,i.ht)(`
      INSERT INTO payments (
        booking_id, amount, currency, payment_method, status,
        transaction_id, payment_date, notes, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,[o.booking_id,o.amount,o.currency,o.payment_method,o.status,o.transaction_id||null,o.payment_date||null,o.notes||null,r.id]),d=await queryOne(`
      SELECT p.*, 
             b.booking_reference, b.destination,
             c.first_name, c.last_name, c.email, c.phone
      FROM payments p
      LEFT JOIN bookings b ON p.booking_id = b.id
      LEFT JOIN customers c ON b.customer_id = c.id
      WHERE p.id = ?
    `,[p.insertId]);return Response.json({success:!0,message:"Payment created successfully",data:{payment:d}},{status:201})}catch(e){return console.error("Create payment error:",e),Response.json({success:!1,message:"Internal server error"},{status:500})}}let l=new a.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/payments/route",pathname:"/api/payments",filename:"route",bundlePath:"app/api/payments/route"},resolvedPagePath:"D:\\codes\\andA - Copy\\src\\app\\api\\payments\\route.js",nextConfigOutput:"",userland:r}),{requestAsyncStorage:g,staticGenerationAsyncStorage:b,serverHooks:y}=l,_="/api/payments/route";function h(){return(0,o.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:b})}}};var t=require("../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[8948,6898,2216,91,7070,9853],()=>s(13465));module.exports=r})();