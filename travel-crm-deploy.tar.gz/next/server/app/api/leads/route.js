"use strict";(()=>{var e={};e.id=5350,e.ids=[5350],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},98216:e=>{e.exports=require("net")},35816:e=>{e.exports=require("process")},76162:e=>{e.exports=require("stream")},74026:e=>{e.exports=require("string_decoder")},95346:e=>{e.exports=require("timers")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},9634:(e,s,t)=>{t.r(s),t.d(s,{originalPathname:()=>E,patchFetch:()=>h,requestAsyncStorage:()=>m,routeModule:()=>g,serverHooks:()=>O,staticGenerationAsyncStorage:()=>_});var r={};t.r(r),t.d(r,{GET:()=>c,POST:()=>p});var a=t(49303),n=t(88716),o=t(60670);t(87070);var i=t(35042),u=t(68408),l=t(78776);let d=l.object({customer_id:l.number().integer().allow(null),source:l.string().min(2).max(100).required(),destination:l.string().min(2).max(100).required(),travel_date:l.date().allow(""),return_date:l.date().allow(""),travelers_count:l.number().integer().min(1).default(1),budget_range:l.string().allow(""),status:l.string().valid("new","contacted","qualified","proposal","negotiation","closed_won","closed_lost").default("new"),priority:l.string().valid("low","medium","high","urgent").default("medium"),notes:l.string().allow(""),assigned_to:l.number().integer().allow(null)});async function c(e){try{let s=e.headers.get("authorization");if(!s||!s.startsWith("Bearer "))return Response.json({success:!1,message:"Access denied. No token provided."},{status:401});let t=s.substring(7);if(!await (0,u.WX)(t))return Response.json({success:!1,message:"Invalid token."},{status:401});let{searchParams:r}=new URL(e.url),a=parseInt(r.get("page"))||1,n=parseInt(r.get("limit"))||10,o=r.get("search")||"",l=r.get("status")||"",d=r.get("priority")||"",c=r.get("sortBy")||"created_at",p=r.get("sortOrder")||"DESC",g="WHERE 1=1",m=[];o&&(g+=" AND (l.source LIKE ? OR l.destination LIKE ? OR l.notes LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ?)",m.push(`%${o}%`,`%${o}%`,`%${o}%`,`%${o}%`,`%${o}%`)),l&&(g+=" AND l.status = ?",m.push(l)),d&&(g+=" AND l.priority = ?",m.push(d));let _=`
      SELECT COUNT(*) as total 
      FROM leads l
      LEFT JOIN customers c ON l.customer_id = c.id
      ${g}
    `,O=(await queryOne(_,m)).total,E=(a-1)*n,h=`
      SELECT l.*, 
             c.first_name, c.last_name, c.email, c.phone,
             u.name as assigned_to_name
      FROM leads l
      LEFT JOIN customers c ON l.customer_id = c.id
      LEFT JOIN users u ON l.assigned_to = u.id
      ${g}
      ORDER BY l.${c} ${p}
      LIMIT ? OFFSET ?
    `,v=await (0,i.IO)(h,[...m,n,E]);return Response.json({success:!0,data:{leads:v,pagination:{page:a,limit:n,total:O,pages:Math.ceil(O/n)}}})}catch(e){return console.error("Get leads error:",e),Response.json({success:!1,message:"Internal server error"},{status:500})}}async function p(e){try{let s=e.headers.get("authorization");if(!s||!s.startsWith("Bearer "))return Response.json({success:!1,message:"Access denied. No token provided."},{status:401});let t=s.substring(7),r=await (0,u.WX)(t);if(!r)return Response.json({success:!1,message:"Invalid token."},{status:401});let a=await e.json(),{error:n,value:o}=d.validate(a);if(n)return Response.json({success:!1,message:"Validation error",errors:n.details.map(e=>e.message)},{status:400});let l=await (0,i.ht)(`
      INSERT INTO leads (
        customer_id, source, destination, travel_date, return_date,
        travelers_count, budget_range, status, priority, notes, assigned_to, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,[o.customer_id||null,o.source,o.destination,o.travel_date||null,o.return_date||null,o.travelers_count,o.budget_range||null,o.status,o.priority,o.notes||null,o.assigned_to||null,r.id]),c=await queryOne(`
      SELECT l.*, 
             c.first_name, c.last_name, c.email, c.phone,
             u.name as assigned_to_name
      FROM leads l
      LEFT JOIN customers c ON l.customer_id = c.id
      LEFT JOIN users u ON l.assigned_to = u.id
      WHERE l.id = ?
    `,[l.insertId]);return Response.json({success:!0,message:"Lead created successfully",data:{lead:c}},{status:201})}catch(e){return console.error("Create lead error:",e),Response.json({success:!1,message:"Internal server error"},{status:500})}}let g=new a.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/leads/route",pathname:"/api/leads",filename:"route",bundlePath:"app/api/leads/route"},resolvedPagePath:"D:\\codes\\andA - Copy\\src\\app\\api\\leads\\route.js",nextConfigOutput:"",userland:r}),{requestAsyncStorage:m,staticGenerationAsyncStorage:_,serverHooks:O}=g,E="/api/leads/route";function h(){return(0,o.patchFetch)({serverHooks:O,staticGenerationAsyncStorage:_})}}};var s=require("../../../webpack-runtime.js");s.C(e);var t=e=>s(s.s=e),r=s.X(0,[8948,6898,2216,91,7070,9853],()=>t(9634));module.exports=r})();