"use strict";(()=>{var e={};e.id=505,e.ids=[505],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},98216:e=>{e.exports=require("net")},35816:e=>{e.exports=require("process")},76162:e=>{e.exports=require("stream")},74026:e=>{e.exports=require("string_decoder")},95346:e=>{e.exports=require("timers")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},30608:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>_,patchFetch:()=>v,requestAsyncStorage:()=>m,routeModule:()=>p,serverHooks:()=>g,staticGenerationAsyncStorage:()=>q});var s={};r.r(s),r.d(s,{GET:()=>d,POST:()=>l});var i=r(49303),a=r(88716),o=r(60670);r(87070),r(35042);var n=r(68408),u=r(78776);let c=u.object({lead_id:u.number().integer().allow(null),customer_id:u.number().integer().required(),title:u.string().min(2).max(200).required(),description:u.string().allow(""),total_amount:u.number().positive().required(),currency:u.string().length(3).default("INR"),valid_until:u.date().allow(""),status:u.string().valid("draft","sent","accepted","rejected","expired").default("draft"),terms_conditions:u.string().allow(""),items:u.array().items(u.object({item_type:u.string().required(),description:u.string().required(),quantity:u.number().positive().required(),unit_price:u.number().positive().required(),total_price:u.number().positive().required()})).default([])});async function d(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return Response.json({success:!1,message:"Access denied. No token provided."},{status:401});let r=t.substring(7);if(!await (0,n.WX)(r))return Response.json({success:!1,message:"Invalid token."},{status:401});let{searchParams:s}=new URL(e.url),i=parseInt(s.get("page"))||1,a=parseInt(s.get("limit"))||10,o=s.get("search")||"",u=s.get("status")||"",c=s.get("sortBy")||"created_at",d=s.get("sortOrder")||"DESC",l="WHERE 1=1",p=[];o&&(l+=" AND (q.title LIKE ? OR q.description LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ?)",p.push(`%${o}%`,`%${o}%`,`%${o}%`,`%${o}%`)),u&&(l+=" AND q.status = ?",p.push(u));let m=`
      SELECT COUNT(*) as total 
      FROM quotes q
      LEFT JOIN customers c ON q.customer_id = c.id
      ${l}
    `,q=(await db.queryOne(m,p)).total,g=(i-1)*a,_=`
      SELECT q.*, 
             c.first_name, c.last_name, c.email, c.phone,
             l.source, l.destination
      FROM quotes q
      LEFT JOIN customers c ON q.customer_id = c.id
      LEFT JOIN leads l ON q.lead_id = l.id
      ${l}
      ORDER BY q.${c} ${d}
      LIMIT ? OFFSET ?
    `,v=await db.query(_,[...p,a,g]);return Response.json({success:!0,data:{quotes:v,pagination:{page:i,limit:a,total:q,pages:Math.ceil(q/a)}}})}catch(e){return console.error("Get quotes error:",e),Response.json({success:!1,message:"Internal server error"},{status:500})}}async function l(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return Response.json({success:!1,message:"Access denied. No token provided."},{status:401});let r=t.substring(7),s=await (0,n.WX)(r);if(!s)return Response.json({success:!1,message:"Invalid token."},{status:401});let i=await e.json(),{error:a,value:o}=c.validate(i);if(a)return Response.json({success:!1,message:"Validation error",errors:a.details.map(e=>e.message)},{status:400});let u=`QT-${Date.now()}-${Math.random().toString(36).substr(2,4).toUpperCase()}`,d=await db.execute(`
      INSERT INTO quotes (
        lead_id, customer_id, title, description, total_amount, currency,
        valid_until, status, terms_conditions, quote_reference, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,[o.lead_id||null,o.customer_id,o.title,o.description||null,o.total_amount,o.currency,o.valid_until||null,o.status,o.terms_conditions||null,u,s.id]),l=await db.queryOne(`
      SELECT q.*, 
             c.first_name, c.last_name, c.email, c.phone,
             l.source, l.destination
      FROM quotes q
      LEFT JOIN customers c ON q.customer_id = c.id
      LEFT JOIN leads l ON q.lead_id = l.id
      WHERE q.id = ?
    `,[d.insertId]);return Response.json({success:!0,message:"Quote created successfully",data:{quote:l}},{status:201})}catch(e){return console.error("Create quote error:",e),Response.json({success:!1,message:"Internal server error"},{status:500})}}let p=new i.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/quotes/route",pathname:"/api/quotes",filename:"route",bundlePath:"app/api/quotes/route"},resolvedPagePath:"D:\\codes\\andA - Copy\\src\\app\\api\\quotes\\route.js",nextConfigOutput:"",userland:s}),{requestAsyncStorage:m,staticGenerationAsyncStorage:q,serverHooks:g}=p,_="/api/quotes/route";function v(){return(0,o.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:q})}}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[8948,6898,2216,91,7070,9853],()=>r(30608));module.exports=s})();